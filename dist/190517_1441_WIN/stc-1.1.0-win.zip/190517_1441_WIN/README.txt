Title: Squaring The Circle
Authors: Oliver Steptoe, Ali Brewin, Anton Nikitin

***STARTING THE GAME***

//WINDOWS
double click on the .exe file

//LINUX
run "java -jar stc-1.1.0.jar" in terminal to start the game
